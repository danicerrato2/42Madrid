# tester for 42 project 
this tester count the number of operation that made by your programme and test if your programme sort correctly or not.</br>
<li><strong>NOTE : </strong> this testr does not check if your checker is work or note</br>

## How do i run this tester ?
<pre>git clone git@github.com:Yoo0lh/push_swap_tester.git </br>./push_swap_tester.sh [number of argument]
</pre>
### example :
this example will run the tester with 5 number of argument
<pre> ./push_swap_tester.sh 5 </pre>
<img src="img/Screen%20Shot%202022-02-01%20at%2010.12.57%20PM.png">

# Contribution
If you noticed something wrong with the code or if you'd like to see a new feature, you can submit an issue. If you'd like to contribute please submit a pull request. 

